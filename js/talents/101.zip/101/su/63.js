{
	"id":63,
	"imageid":63,
	"name":{
		"ru":"Подсумок",
		"en":"Pouch"
	},
	"description":{
		"ru":"Открывает одну ячейку для активных предметов.",
		"en":"Unlocks one cell for active items"
	},
	"effect":{
		"ru":"Увеличивает количество активных слотов на 1.",
		"en":"Increases number of active slots for 1"
	},
	"cost":1,
	"lvlreq":10,
	"column":0
}