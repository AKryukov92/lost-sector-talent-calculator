{
	"id":83,
	"imageid":83,
	"name":{
		"ru":"Чувство локтя",
		"en":"Common touch"
	},
	"description":{
		"ru":"Если рядом с наемником есть союзник, оба наносят на 10% урона больше.",
		"en":"If there's an ally near the mercenary, both deal 10% more damage."
	},
	"cost":1,
	"lvlreq":8,
	"radius":20,
	"talentreq":411,
	"column":10
}