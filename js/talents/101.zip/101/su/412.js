{
	"id":412,
	"imageid":41,
	"name":{
		"ru":"Огнеупорный",
		"en":"Fire resistant"
	},
	"description":{
		"ru":"Добавляет базовое сопротивление огню.",
		"en":"Adds basic resistance to fire."
	},
	"effect":{
		"ru":"Увеличивает сопротивление огню на 12%",
		"en":"Increases fire resist for 12%"
	},
	"cost":2,
	"lvlreq":9,
	"rankof":411,
	"column":9
}