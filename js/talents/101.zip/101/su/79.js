{
	"id":79,
	"imageid":79,
	"name":{
		"ru":"Вендетта",
		"en":"Vendetta"
	},
	"description":{
		"ru":"При смерти члена вашей команды увеличивает наносимый урон всеми бойцами команды на 15% на 1 ход. Эффект не суммируется.",
		"en":"When a member from your team dies, increases inflicting damage to all the team units by 15% for one turn. The effect does not stack."
	},
	"cost":1,
	"lvlreq":12,
	"talentreq":46,
	"column":11
}