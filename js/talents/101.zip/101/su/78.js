{
	"id":78,
	"imageid":78,
	"name":{
		"ru":"Открывашка",
		"en":"Opener"
	},
	"description":{
		"ru":"Первая пуля, снаряд, граната или удар по цели с полной броней наносит 140% повреждений.",
		"en":"The first bullet, shell, grenade or a hit at a target with full armor deals 140% damage."
	},
	"cost":1,
	"lvlreq":8,
	"talentreq":411,
	"column":9
}