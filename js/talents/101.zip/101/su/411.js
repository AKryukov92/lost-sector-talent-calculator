{
	"id":411,
	"imageid":41,
	"name":{
		"ru":"Огнеупорный",
		"en":"Fire resistant"
	},
	"description":{
		"ru":"Добавляет базовое сопротивление огню.",
		"en":"Adds basic resistance to fire."
	},
	"effect":{
		"ru":"Увеличивает сопротивление огню на 7%",
		"en":"Increases fire resist for 7%"
	},
	"cost":1,
	"lvlreq":6,
	"column":9
}