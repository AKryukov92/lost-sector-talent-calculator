{
	"id":61,
	"imageid":61,
	"name":{
		"ru":"Быстрая перезарядка",
		"en":"Quick reload"
	},
	"description":{
		"ru":"Перезаряжает основное оружие не тратя запас.",
		"en":"Reloads the main weapon, without spending the ammution."
	},
	"cost":1,
	"lvlreq":6,
	"talentreq":421,
	"column":8
}