{
	"id":421,
	"imageid":42,
	"name":{
		"ru":"Взрывостойкий",
		"en":"Explosion resistant"
	},
	"description":{
		"ru":"Добавляет базовое сопротивление взрывам.",
		"en":"Adds basic resistance to explosions."
	},
	"effect":{
		"ru":"Увеличивает сопротивление взрывам на 5%",
		"en":"Increases explosion resist for 5%"
	},
	"cost":1,
	"lvlreq":5,
	"column":7
}