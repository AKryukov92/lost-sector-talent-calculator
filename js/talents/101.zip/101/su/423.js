{
	"id":423,
	"imageid":42,
	"name":{
		"ru":"Взрывостойкий",
		"en":"Explosion resistant"
	},
	"description":{
		"ru":"Добавляет базовое сопротивление взрывам.",
		"en":"Adds basic resistance to explosions."
	},
	"effect":{
		"ru":"Увеличивает сопротивление взрывам на 15%",
		"en":"Increases explosion resist for 15%"
	},
	"cost":3,
	"lvlreq":11,
	"rankof":421,
	"column":7
}