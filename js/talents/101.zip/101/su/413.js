{
	"id":413,
	"imageid":41,
	"name":{
		"ru":"Огнеупорный",
		"en":"Fire resistant"
	},
	"description":{
		"ru":"Добавляет базовое сопротивление огню.",
		"en":"Adds basic resistance to fire."
	},
	"effect":{
		"ru":"Увеличивает сопротивление огню на 20%",
		"en":"Increases fire resist for 20%"
	},
	"cost":3,
	"lvlreq":12,
	"rankof":411,
	"column":9
}