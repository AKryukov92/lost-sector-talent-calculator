{
	"id":75,
	"imageid":75,
	"name":{
		"ru":"Берсеркер",
		"en":"Berserker"
	},
	"description":{
		"ru":"При получении наемником 115 повреждений за один ход, увеличивает его очки действий на 20 на 1 ход. Счетчик сбрасывается в начале хода.",
		"en":"When a mercenary receives 115 damage at a turn, he receives 20 additional AP for next turn. The counter resets at the beginning of the turn."
	},
	"cost":1,
	"lvlreq":10,
	"talentreq":401,
	"column":7
}