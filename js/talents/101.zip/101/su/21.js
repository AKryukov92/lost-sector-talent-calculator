{
	"id":21,
	"imageid":21,
	"name":{
		"ru":"Пусковые установки (профессионал)",
		"en":"Launchers (professional)"
	},
	"description":{
		"ru":"Позволяет использовать пусковые установки армейской классификации.",
		"en":"Launchers using skill of military classification."
	},
	"cost":1,
	"lvlreq":8,
	"talentreq":12,
	"column":5
}