{
	"id":46,
	"imageid":46,
	"name":{
		"ru":"Личная броня",
		"en":"Personal armor"
	},
	"description":{
		"ru":"Увеличивает базовое количество брони.",
		"en":"Increases basic amount of armor."
	},
	"effect":{
		"ru":"Увеличивает запас брони на 10",
		"en":"Increases defence maximum for 10"
	},
	"cost":1,
	"lvlreq":8,
	"column":11
}