{
	"id":18,
	"imageid":18,
	"name":{
		"ru":"Техник (профессионал)",
		"en":"Technician (professional)"
	},
	"description":{
		"ru":"Позволяет устанавливать сложное оборудование в зоне битвы.",
		"en":"Allows you to set up complex equipment in the battle zone."
	},
	"cost":1,
	"lvlreq":7,
	"talentreq":5,
	"column":3
}