{
	"id":403,
	"imageid":40,
	"name":{
		"ru":"Химзащита",
		"en":"Chemical resistant"
	},
	"description":{
		"ru":"Добавляет базовое сопротивление кислоте.",
		"en":"Adds basic resitance to acid."
	},
	"effect":{
		"ru":"Увеличивает сопротивление кислоте на 30%",
		"en":"Increases acid resist for 30%"
	},
	"cost":3,
	"lvlreq":13,
	"rankof":401,
	"column":7
}