{
	"id":12,
	"imageid":12,
	"name":{
		"ru":"Пусковые установки (специалист)",
		"en":"Launchers (specialist)"
	},
	"description":{
		"ru":"Позволяет использовать пусковые установки полицейской классификации.",
		"en":"Launchers using skill of police classification."
	},
	"cost":1,
	"lvlreq":5,
	"column":5
}