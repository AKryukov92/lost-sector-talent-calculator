{
	"id":60,
	"imageid":60,
	"name":{
		"ru":"Восстановление",
		"en":"Recovery"
	},
	"description":{
		"ru":"Восстанавливает 35 ед. брони и 35 ед. здоровья союзному наемнику.",
		"en":"Recovers 35 armor units and 35 health units to an ally mercenary."
	},
	"cost":1,
	"lvlreq":6,
	"talentreq":421,
	"number_of_uses":3,
	"AP_cost":55,
	"radius":1,
	"column":7
}