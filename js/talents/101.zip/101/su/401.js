{
	"id":401,
	"imageid":40,
	"name":{
		"ru":"Химзащита",
		"en":"Chemical resistant"
	},
	"description":{
		"ru":"Добавляет базовое сопротивление кислоте.",
		"en":"Adds basic resitance to acid."
	},
	"effect":{
		"ru":"Увеличивает сопротивление кислоте на 10%",
		"en":"Increases acid resist for 10%"
	},
	"cost":1,
	"lvlreq":7,
	"column":7
}