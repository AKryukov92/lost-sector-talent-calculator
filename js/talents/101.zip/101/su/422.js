{
	"id":422,
	"imageid":42,
	"name":{
		"ru":"Взрывостойкий",
		"en":"Explosion resistant"
	},
	"description":{
		"ru":"Добавляет базовое сопротивление взрывам.",
		"en":"Adds basic resistance to explosions."
	},
	"effect":{
		"ru":"Увеличивает сопротивление взрывам на 10%",
		"en":"Increases explosion resist for 10%"
	},
	"cost":2,
	"lvlreq":8,
	"rankof":421,
	"column":7
}