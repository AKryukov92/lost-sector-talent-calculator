{
	"id":402,
	"imageid":40,
	"name":{
		"ru":"Химзащита",
		"en":"Chemical resistant"
	},
	"description":{
		"ru":"Добавляет базовое сопротивление кислоте.",
		"en":"Adds basic resitance to acid."
	},
	"effect":{
		"ru":"Увеличивает сопротивление кислоте на 20%",
		"en":"Increases acid resist for 20%"
	},
	"cost":2,
	"lvlreq":10,
	"rankof":401,
	"column":7
}