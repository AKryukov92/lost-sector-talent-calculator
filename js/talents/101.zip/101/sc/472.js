{
	"id":472,
	"imageid":47,
	"name":{
		"ru":"Эксперт по баллистике",
		"en":"Ballistics expert"
	},
	"description":{
		"ru":"Увеличивает наносимый урон.",
		"en":"Increases inflicting damage."
	},
	"effect":{
		"ru":"Увеличивает наносимый урон (кроме ближнего боя) на 8%",
		"en":"Increases damage multiplier (except melee) for 8%"
	},
	"cost":3,
	"lvlreq":8,
	"rankof":471,
	"column":7
}