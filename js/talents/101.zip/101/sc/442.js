{
	"id":442,
	"imageid":44,
	"name":{
		"ru":"Искусство боя",
		"en":"Martial art"
	},
	"description":{
		"ru":"Увеличивает наносимый урон в ближнем бою.",
		"en":"Increases inflicting damage at close combat."
	},
	"effect":{
		"ru":"Увеличивает урон в ближнем бою на 40%",
		"en":"Increases melee damage multiplier for 40%"
	},
	"cost":2,
	"lvlreq":11,
	"rankof":441,
	"column":7
}