{
	"id":87,
	"imageid":87,
	"name":{
		"ru":"Чутье",
		"en":"Sense"
	},
	"description":{
		"ru":"Наемник чувствует присутствие противников рядом.",
		"en":"The mercenary feels at the presence of enemies."
	},
	"cost":1,
	"lvlreq":8,
	"talentreq":451,
	"radius":15,
	"column":10
}