{
	"id":5,
	"imageid":5,
	"name":{
		"ru":"Техник (специалист)",
		"en":"Technician (specialist)"
	},
	"description":{
		"ru":"Позволяет устанавливать простое оборудование в зоне битвы.",
		"en":"Allows you to set simple equipment in the battle zone."
	},
	"cost":1,
	"lvlreq":6,
	"column":3
}