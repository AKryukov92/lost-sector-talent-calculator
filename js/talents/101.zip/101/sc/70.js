{
	"id":70,
	"imageid":70,
	"name":{
		"ru":"Упор",
		"en":"Lean"
	},
	"description":{
		"ru":"Увеличивает точность наемника на 7 в сидячем положении.",
		"en":"Increases accuracy by 7 units in sitting position."
	},
	"cost":1,
	"lvlreq":8,
	"talentreq":451,
	"column":8
}