{
	"id":471,
	"imageid":47,
	"name":{
		"ru":"Эксперт по баллистике",
		"en":"Ballistics expert"
	},
	"description":{
		"ru":"Увеличивает наносимый урон.",
		"en":"Increases inflicting damage."
	},
	"effect":{
		"ru":"Увеличивает наносимый урон (кроме ближнего боя) на 5%",
		"en":"Increases damage multiplier (except melee) for 5%"
	},
	"cost":1,
	"lvlreq":5,
	"column":7
}