{
	"id":86,
	"imageid":86,
	"name":{
		"ru":"Стрелять до конца",
		"en":"Shoot 'till the end"
	},
	"description":{
		"ru":"Следующая атака после активации потратит все ваши ОД, но будет иметь повышенный на 50% шанс критического попадания. Шанс считается для каждой пули отдельно. Для активации можно использовать очки движения.",
		"en":"The next attack after activation will spend all of your AP and MP, but will have a 50% heihtened chance to deal critical strike. The chance is considered separately per bullet. For activation you can use MP (movement points)."
	},
	"cost":1,
	"lvlreq":10,
	"talentreq":43,
	"AP_cost":1,
	"column":6
}