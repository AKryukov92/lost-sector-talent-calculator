{
	"id":72,
	"imageid":72,
	"name":{
		"ru":"Пристрелка",
		"en":"Adjustment fire"
	},
	"description":{
		"ru":"Увеличивает точность наемника на 8 ед., увеличивает максимальный радиус оружия на 1 метр и уменьшает минимальный радиус оружия на 1 метр за каждую атаку наёмника. Эффект суммируется. Счетчик сбрасывается в начале хода.",
		"en":"Increases weapon's accuracy by 8 units, increases weapon's maximal radius by 1 meter for each of a mercenary's consecutive attack. The effect stacks. The counter resets at the beginning of the turn."
	},
	"cost":1,
	"lvlreq":10,
	"talentreq":43,
	"column":4
}