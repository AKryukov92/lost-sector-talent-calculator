{
	"id":73,
	"imageid":73,
	"name":{
		"ru":"Подавляющая высота",
		"en":"Overwhelmed height"
	},
	"description":{
		"ru":"Увеличивает шанс критической атаки на 30% по цели, находящейся на 2 или более метров ниже наемника. Шанс считается для каждой пули отдельно.",
		"en":"Increases the chance of critical attack by 30% for the target located 2 meters below or more. Chance is calculated for each bullet separately"
	},
	"cost":1,
	"lvlreq":8,
	"talentreq":451,
	"radius":2,
	"column":9
}