{
	"id":13,
	"imageid":13,
	"name":{
		"ru":"Снайперские винтовки (специалист)",
		"en":"Sniper Rifles (specialist)"
	},
	"description":{
		"ru":"Позволяет использовать снайперские винтовки полицейской классификации.",
		"en":"Sniper Rifles usig skill of police classification."
	},
	"cost":1,
	"lvlreq":5,
	"column":6
}