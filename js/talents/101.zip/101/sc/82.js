{
	"id":82,
	"imageid":82,
	"name":{
		"ru":"Справедливый суд",
		"en":"Fair verdict"
	},
	"description":{
		"ru":"При убийстве наемником врага, все союзники (кроме него) получают бонус в 20% мобильности на 1 ход. Эффект не суммируется.",
		"en":"When the mercenary kills an enemy all the allies (except of him) gets 20% additional mobility for 1 turn. Effect does not stack."
	},
	"cost":1,
	"lvlreq":12,
	"talentreq":441,
	"column":8
}