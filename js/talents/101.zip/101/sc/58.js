{
	"id":58,
	"imageid":58,
	"name":{
		"ru":"Тактическая оценка",
		"en":"Tactical estimation"
	},
	"description":{
		"ru":"Уменьшает общее сопротивление выбранного противника на 30% на 1 ход.",
		"en":"Decreases the general resistance of the selected enemy by 30% for one turn."
	},
	"cost":1,
	"lvlreq":6,
	"talentreq":471,
	"AP_cost":60,
	"number_of_uses":2,
	"radius":100,
	"column":7
}