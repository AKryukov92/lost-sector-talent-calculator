{
	"id":441,
	"imageid":44,
	"name":{
		"ru":"Искусство боя",
		"en":"Martial art"
	},
	"description":{
		"ru":"Увеличивает наносимый урон в ближнем бою.",
		"en":"Increases inflicting damage at close combat."
	},
	"effect":{
		"ru":"Увеличивает урон в ближнем бою на 20%",
		"en":"Increases melee damage multiplier for 20%"
	},
	"cost":1,
	"lvlreq":8,
	"column":7
}