{
	"id":59,
	"imageid":59,
	"name":{
		"ru":"Концентрация",
		"en":"Concentration"
	},
	"description":{
		"ru":"Увеличивает наносимый урон на 25% до конца хода и снимает 20 ОД на следующем ходу.",
		"en":"Increases mercenary's inflicting damage by 25% to the end of the turn and removes 20AP on the next turn."
	},
	"cost":1,
	"lvlreq":6,
	"talentreq":471,
	"AP_cost":30,
	"number_of_uses":2,
	"column":8
}