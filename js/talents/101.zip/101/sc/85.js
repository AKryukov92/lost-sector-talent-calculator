{
	"id":85,
	"imageid":85,
	"name":{
		"ru":"Критический урон",
		"en":"Critical damage"
	},
	"description":{
		"ru":"Увеличивает повреждения от критических атак наемника.",
		"en":"Increases the critical damage dealt by the mercenary."
	},
	"effect":{
		"ru":"Устанавливает множитель урона от крит. попаданий равным 2",
		"en":"Sets crit.hit damage multiplier equal to 2"
	},
	"cost":1,
	"lvlreq":10,
	"talentreq":43,
	"column":5
}