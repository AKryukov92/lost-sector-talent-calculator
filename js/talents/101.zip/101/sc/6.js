{
	"id":6,
	"imageid":6,
	"name":{
		"ru":"Пистолеты (специалист)",
		"en":"Pistols (specialist)"
	},
	"description":{
		"ru":"Позволяет использовать пистолеты полицейской классификации.",
		"en":"Pistols using skill of police classification."
	},
	"cost":1,
	"lvlreq":5,
	"column":4
}