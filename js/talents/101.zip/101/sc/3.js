{
	"id":3,
	"imageid":3,
	"name":{
		"ru":"Тактические гранаты",
		"en":"Tactical grenades"
	},
	"description":{
		"ru":"Позволяет использовать тактические гранаты по типу ребис и ЭМ гранат.",
		"en":"Allows you to use tactical grenades of Rebis & EM types."
	},
	"cost":1,
	"lvlreq":5,
	"talentreq":4,
	"column":0
}