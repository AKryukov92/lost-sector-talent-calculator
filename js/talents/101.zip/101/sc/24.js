{
	"id":24,
	"imageid":24,
	"name":{
		"ru":"Снайперские винтовки (профессионал)",
		"en":"Sniper Rifles (professional)"
	},
	"description":{
		"ru":"Позволяет использовать снайперские винтовки армейской классификации.",
		"en":"Sniper Rifles using skill of military classification."
	},
	"cost":1,
	"lvlreq":8,
	"talentreq":13,
	"column":6
}