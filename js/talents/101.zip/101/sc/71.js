{
	"id":71,
	"imageid":71,
	"name":{
		"ru":"Сошки",
		"en":"Bipods"
	},
	"description":{
		"ru":"Увеличивает точность наемника на 10 ед., при этом снижая его мобильность в 10 раз. Действует до конца текущего хода.",
		"en":"Increases the mercenary's accuracy by 10 units, but reduces his mobility by 10 times. Works until the ed of the current turn."
	},
	"cost":1,
	"lvlreq":12,
	"talentreq":441,
	"AP_cost":10,
	"column":7
}