{
	"id":77,
	"imageid":77,
	"name":{
		"ru":"Счастливая монетка",
		"en":"Lucky coin"
	},
	"description":{
		"ru":"Спасает от одной смертельной пули или взрыва, но оставляет только 50% текущего здоровья и 0% брони, а также вызывает ослепление на 1 ход. Этот урон не учитывается навыками, срабатывающими от полученного урона.",
		"en":"Saves from one deadly hit, bullet or explosion, but leaves only 50% off the current health and 0% armor, as well as causing blindness ofr 1 turn. This damage does not count by abilities, which turn on from received damage."
	},
	"cost":1,
	"number_of_uses":1,
	"lvlreq":10,
	"talentreq":381,
	"column":8
}