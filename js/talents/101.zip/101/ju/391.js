{
	"id":391,
	"imageid":39,
	"name":{
		"ru":"Стойкий",
		"en":"Staunch"
	},
	"description":{
		"ru":"Добавляет базовое сопротивление любому урону.",
		"en":"Adds basic resistance to any damage."
	},
	"effect":{
		"ru":"Увеличивает общую стойкость к урону на 7%",
		"en":"Increases total resist for 7%"
	},
	"cost":1,
	"lvlreq":5,
	"column":7
}