{
	"id":9,
	"imageid":9,
	"name":{
		"ru":"Щиты (специалист)",
		"en":"Shields (specialist)"
	},
	"description":{
		"ru":"Позволяет использовать щиты полицейской классификации.",
		"en":"Shields using skill of police classification"
	},
	"cost":2,
	"lvlreq":5,
	"column":3
}