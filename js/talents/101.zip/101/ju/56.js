{
	"id":56,
	"imageid":56,
	"name":{
		"ru":"Нянька",
		"en":"Nanny"
	},
	"description":{
		"ru":"Все союзники в указанном радиусе от наемника получают бонус 10% общего сопротивления к урону. Сам наемник бонус не получает.",
		"en":"All allies in the specified range from the mercenary receive 10% bonus to general resistance. The mercenary itself does not receive the bonus."
	},
	"cost":1,
	"lvlreq":6,
	"talentreq":391,
	"column":7,
	"radius":20
}