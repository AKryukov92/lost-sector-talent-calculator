{
	"id":74,
	"imageid":74,
	"name":{
		"ru":"Сбросить лишнее",
		"en":"Put off the ballast"
	},
	"description":{
		"ru":"Увеличивает мобильность наемника на 30% при падении очков брони ниже 40.",
		"en":"Increases the mercenary's mobility by 30% when the armor falls below 40"
	},
	"cost":1,
	"lvlreq":10,
	"talentreq":381,
	"column":7
}