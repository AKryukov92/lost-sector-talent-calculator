{
	"id":23,
	"imageid":23,
	"name":{
		"ru":"Пулеметы (профессионал)",
		"en":"Machineguns (professional)"
	},
	"description":{
		"ru":"Позволяет использовать пулеметы армейской классификации.",
		"en":"Machineguns using skill of military classification."
	},
	"cost":1,
	"lvlreq":7,
	"talentreq":11,
	"column":5
}