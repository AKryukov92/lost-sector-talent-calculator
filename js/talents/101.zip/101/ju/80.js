{
	"id":80,
	"imageid":80,
	"name":{
		"ru":"Мученик",
		"en":"Martyr"
	},
	"description":{
		"ru":"При получении суммарно 200 повреждений, всем прочим бойцам вашей команды выдается бонус 20% общего сопротивления на 1 ход. Счетчик сбрасывается при срабатывании.",
		"en":"When receiving summarily 200 damage, the rest fighters of your team are granted a 20% bonus of general resistance for one turn. The counter resets after actuation."
	},
	"cost":1,
	"lvlreq":12,
	"talentreq":441,
	"column":0
}