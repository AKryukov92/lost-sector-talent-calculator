{
	"id":483,
	"imageid":48,
	"name":{
		"ru":"Крепкий",
		"en":"Solid"
	},
	"description":{
		"ru":"Увеличивает базовое количество здоровья.",
		"en":"Increases the basic amount of health"
	},
	"effect":{
		"ru":"Увеличивает запас здоровья на 35.",
		"en":"Increases health maximum for 35."
	},
	"cost":4,
	"lvlreq":13,
	"rankof":481,
	"column":9
}