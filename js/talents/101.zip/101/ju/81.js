{
	"id":81,
	"imageid":81,
	"name":{
		"ru":"Злопамятный",
		"en":"Vidictive"
	},
	"description":{
		"ru":"При получении наемником повреждений, у персонажа, нанесшего ему урон последним, уменьшается общее сопротивление на 15% на 1 ход. Эффект действует, только если  бою присутствует не менее 2 живых противников.",
		"en":"When the mercenary receives damage, the unit that dealt that damage, receives a 15% decrease of general resistance for 1 round. The effect is only valid, if at the battle there are not less than 2 enemies alive."
	},
	"cost":1,
	"lvlreq":12,
	"talentreq":441,
	"column":1
}