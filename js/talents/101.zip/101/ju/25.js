{
	"id":25,
	"imageid":25,
	"name":{
		"ru":"Боевые гранаты",
		"en":"Battle grenades"
	},
	"description":{
		"ru":"Позволяет использовать боевые гранаты.",
		"en":"Allows you to use combat grenades."
	},
	"cost":1,
	"lvlreq":7,
	"talentreq":4,
	"column":0
}