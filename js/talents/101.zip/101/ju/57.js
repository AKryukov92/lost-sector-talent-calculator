{
	"id":57,
	"imageid":57,
	"name":{
		"ru":"Глухая оборона",
		"en":"Blind defense"
	},
	"description":{
		"ru":"Увеличивает общее сопротивление наемника на 40% на 1 ход, при этом боец теряет способность видеть врага.",
		"en":"Increase the mercenary's general resistance by 40% for 1 turn, but he is losing the ability to see the enemy."
	},
	"cost":1,
	"lvlreq":6,
	"AP_cost":20,
	"number_of_uses":2,
	"talentreq":391,
	"column":8
}