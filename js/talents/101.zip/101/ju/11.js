{
	"id":11,
	"imageid":11,
	"name":{
		"ru":"Пулеметы (специалист)",
		"en":"Machineguns (specialish)"
	},
	"description":{
		"ru":"Позволяет использовать пулеметы полицейской классификации.",
		"en":"Machineguns using skill of police classification."
	},
	"cost":1,
	"lvlreq":5,
	"column":5
}