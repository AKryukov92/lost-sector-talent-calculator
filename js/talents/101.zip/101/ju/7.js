{
	"id":7,
	"imageid":7,
	"name":{
		"ru":"Холодное оружие (специалист)",
		"en":"Melee weapon (specialist)"
	},
	"description":{
		"ru":"Позволяет использовать холодное оружие полицейской классификации.",
		"en":"Melee weapon using skill of police classification."
	},
	"lvlreq":6,
	"cost":1,
	"column":3
}