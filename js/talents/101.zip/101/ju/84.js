{
	"id":84,
	"imageid":84,
	"name":{
		"ru":"Без зазоров",
		"en":"No gaps"
	},
	"description":{
		"ru":"Критические атаки не наносят наемнику дополнительных повреждений.",
		"en":"Critical strikes do not deal additional damage to the mercenary."
	},
	"cost":1,
	"lvlreq":8,
	"talentreq":481,
	"column":10
}