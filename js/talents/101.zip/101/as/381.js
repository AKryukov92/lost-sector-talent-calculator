{
	"id":381,
	"imageid":38,
	"name":{
		"ru":"Восприимчивость к восстановлению",
		"en":"Perceptivity to recovery"
	},
	"description":{
		"ru":"Увеличивает эффективность восстановления своего здоровья и брони.",
		"en":"Increases the incoming recovering of health and armor"
	},
	"effect":{
		"ru":"Увеличивает эффективность лечения на 20%.",
		"en":"Increases healing effectiveness for 20%"
	},
	"cost":1,
	"lvlreq":7,
	"row":7,
	"column":7
}