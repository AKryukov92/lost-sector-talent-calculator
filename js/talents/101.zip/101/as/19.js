{
	"id":19,
	"imageid":19,
	"name":{
		"ru":"Пистолеты (профессионал)",
		"en":"Pistols (professional)"
	},
	"description":{
		"ru":"Позволяет использовать пистолеты армейской или крупнокалиберной классификации.",
		"en":"Pistols using skill of military or large-caliber classification."
	},
	"cost":1,
	"lvlreq":8,
	"talentreq":6,
	"column":3
}