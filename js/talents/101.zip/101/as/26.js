{
	"id":26,
	"imageid":26,
	"name":{
		"ru":"Пистолеты-пулеметы (профессионал)",
		"en":"Sub-machine guns (professional)"
	},
	"description":{
		"ru":"Позволяет использовать пистолеты-пулеметы армейской классификации.",
		"en":"Sub-machine guns using skill of military classification."
	},
	"cost":1,
	"lvlreq":9,
	"talentreq":8,
	"column":4
}