{
	"id":64,
	"imageid":64,
	"name":{
		"ru":"Заначка",
		"en":"Stash"
	},
	"description":{
		"ru":"Восстанавливает 15 ед. здоровья наемника после использовать активного предмета.",
		"en":"Recovers 15 health units after using an active item."
	},
	"cost":1,
	"lvlreq":10,
	"talentreq":62,
	"column":2
}