{
	"id":451,
	"imageid":45,
	"name":{
		"ru":"Стрельба наверняка",
		"en":"Shooting for sure"
	},
	"description":{
		"ru":"Увеличивает шанс нанести цели критический урон.",
		"en":"Increases the chance to deal critical damage."
	},
	"effect":{
		"ru":"Увеличивает шанс крит.попадания на 2%",
		"en":"Increases crit.hit chance for 2%"
	},
	"cost":1,
	"lvlreq":6,
	"column":9
}