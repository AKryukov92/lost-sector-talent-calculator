{
	"id":51,
	"imageid":51,
	"name":{
		"ru":"Эксперт по оружию",
		"en":"Weapon expert"
	},
	"description":{
		"ru":"Увеличивает наносимый урон.",
		"en":"Increases inflicting damage"
	},
	"effect":{
		"ru":"Увеличивает наносимый урон (кроме ближнего боя) на 5%",
		"en":"Increases damage multiplier (except melee) for 5%"
	},
	"lvlreq":14,
	"column":0
}