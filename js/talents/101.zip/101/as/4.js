{
	"id":4,
	"imageid":4,
	"name":{
		"ru":"Штурмовые гранаты",
		"en":"Assault grenades"
	},
	"description":{
		"ru":"Позволяет пользоваться простыми штурмовыми гранатами.",
		"en":"Allows you to use simple assault grenades in combat."
	},
	"cost":1,
	"lvlreq":3,
	"column":0
}