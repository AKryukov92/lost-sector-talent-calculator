{
	"id":1,
	"imageid":1,
	"name":{
		"ru":"Пассивная регенерация",
		"en":"Passive regeneration"
	},
	"description":{
		"ru":"Медленно восстанавливает здоровье наемника на мирных локациях (Фабрика и другие).",
		"en":"Slow health regeneration in peaceful locations (Factory & etc.)."
	},
	"effect":{
		"ru":"Умножает регенерацию здоровья на 3",
		"en":"Multiplies health regeneration by 3"
	},
	"cost":1,
	"lvlreq":1,
	"column":0
}