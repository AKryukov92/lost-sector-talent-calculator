{
	"id":22,
	"imageid":22,
	"name":{
		"ru":"Штурмовые винтовки (профессионал)",
		"en":"Assault Rifles (professional)"
	},
	"description":{
		"ru":"Позволяет использовать штурмовые винтовки армейской классификации.",
		"en":"Assault Rifles using skill of military classification."
	},
	"cost":1,
	"lvlreq":8,
	"talentreq":10,
	"column":5
}