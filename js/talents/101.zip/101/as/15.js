{
	"id":15,
	"imageid":15,
	"name":{
		"ru":"Подрывник",
		"en":"Demolisher"
	},
	"description":{
		"ru":"Позволяет использовать и устанавливать взрывчатку и мины.",
		"en":"Explosives and mines setting and using skill."
	},
	"cost":1,
	"lvlreq":8,
	"column":1
}