{
	"id":62,
	"imageid":62,
	"name":{
		"ru":"Патронташ",
		"en":"Bandolier"
	},
	"description":{
		"ru":"Открывает одну ячейку для активных предметов.",
		"en":"Unlocks one cell for active items."
	},
	"effect":{
		"ru":"Увеличивает количество активных слотов на 1.",
		"en":"Increases number of active slots for 1"
	},
	"lvlreq":5,
	"column":2
}