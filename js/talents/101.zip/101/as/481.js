{
	"id":481,
	"imageid":48,
	"name":{
		"ru":"Крепкий",
		"en":"Solid"
	},
	"description":{
		"ru":"Увеличивает базовое количество здоровья.",
		"en":"Increases the basic amount of health"
	},
	"effect":{
		"ru":"Увеличивает запас здоровья на 15.",
		"en":"Increases health maximum for 15."
	},
	"cost":1,
	"lvlreq":8,
	"column":11
}