{
	"id":10,
	"imageid":10,
	"name":{
		"ru":"Штурмовые винтовки (специалист)",
		"en":"Assault Rifles (specialist)"
	},
	"description":{
		"ru":"Позволяет использовать штурмовые винтовки полицейской классификации.",
		"en":"Assault Rifles using skill of police classification"
	},
	"cost":1,
	"lvlreq":5,
	"column":5
}