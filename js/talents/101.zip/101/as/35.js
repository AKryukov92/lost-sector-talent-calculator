{
	"id":35,
	"imageid":35,
	"name":{
		"ru":"Стимуляторы",
		"en":"Stimulants"
	},
	"description":{
		"ru":"Позволяет использовать стероидные и адреналиновые препараты.",
		"en":"Allows you to use steroid and adrenaline drugs in the battle."
	},
	"cost":1,
	"lvlreq":4,
	"talentreq":2,
	"column":1
}