{
	"id":453,
	"imageid":45,
	"name":{
		"ru":"Стрельба наверняка",
		"en":"Shooting for sure"
	},
	"description":{
		"ru":"Увеличивает шанс нанести цели критический урон.",
		"en":"Increases the chance to deal critical damage."
	},
	"effect":{
		"ru":"Увеличивает шанс крит.попадания на 10%",
		"en":"Increases crit.hit chance for 10%"
	},
	"cost":3,
	"lvlreq":12,
	"rankof":451,
	"column":9
}