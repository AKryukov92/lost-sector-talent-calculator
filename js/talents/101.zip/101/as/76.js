{
	"id":76,
	"imageid":76,
	"name":{
		"ru":"Счетовод",
		"en":"Accountant"
	},
	"description":{
		"ru":"20% от полученных повреждений суммируются и прибавляются к атаке наемника. Чем выше бронепробиваемость оружия наемника, тем меньше бонус. Счетчик сбрасывается после успешной атаки.",
		"en":"20% of the received damage are summed and added to the mercenary's attack. The higher the armor penetration of the your mercenary's weapon, the lower the bones is. The counter is reset after a successful attack."
	},
	"cost":1,
	"lvlreq":12,
	"talentreq":481,
	"column":11
}