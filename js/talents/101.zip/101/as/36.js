{
	"id":36,
	"imageid":36,
	"name":{
		"ru":"Гермогели",
		"en":"Hermogell"
	},
	"description":{
		"ru":"Позволяет использовать герметики для восстановления брони в бою.",
		"en":"Allows you to use hermetic to repair the armor in the battle"
	},
	"cost":1,
	"lvlreq":7,
	"talentreq":35,
	"column":1
}