{
	"id":8,
	"imageid":8,
	"name":{
		"ru":"Пистолеты-пулеметы (специалист)",
		"en":"Sub-machine guns (specialist)"
	},
	"description":{
		"ru":"позволяет использовать пистолеты-пулеметы полицейской классификации.",
		"en":"Sub-machine guns using skill of police classification."
	},
	"cost":1,
	"lvlreq":6,
	"column":4
}