{
	"id":382,
	"imageid":38,
	"name":{
		"ru":"Восприимчивость к восстановлению",
		"en":"Perceptivity to recovery"
	},
	"description":{
		"ru":"Увеличивает эффективность восстановления своего здоровья и брони.",
		"en":"Increases the incoming recovering of health and armor"
	},
	"effect":{
		"ru":"Увеличивает эффективность лечения на 40%.",
		"en":"Increases healing effectiveness for 40%"
	},
	"cost":2,
	"lvlreq":8,
	"rankof":381,
	"column":7
}