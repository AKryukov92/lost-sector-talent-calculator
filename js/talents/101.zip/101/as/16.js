{
	"id":16,
	"imageid":16,
	"name":{
		"ru":"Гранаты-пауки",
		"en":"Spider grenades"
	},
	"description":{
		"ru":"Позволяет использовать гранаты-пауки.",
		"en":"Allows you to use spider grenades."
	},
	"cost":1,
	"lvlreq":10,
	"talentreq":17,
	"column":0
}