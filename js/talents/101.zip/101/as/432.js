{
	"id":432,
	"imageid":43,
	"name":{
		"ru":"Быстрый бег",
		"en":"Fast running"
	},
	"description":{
		"ru":"Увеличивает количество очков движения, позволяя передвигаться дальше.",
		"en":"Increases the amount of MP (yellow movement points) allowing to move further."
	},
	"effect":{
		"ru":"Увеличивает максимум очков движения на 8",
		"en":"Increases maximum of move points for 8"
	},
	"cost":3,
	"lvlreq":6,
	"rankof":431,
	"column":7
}