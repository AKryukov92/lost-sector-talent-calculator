{
	"id":452,
	"imageid":45,
	"name":{
		"ru":"Стрельба наверняка",
		"en":"Shooting for sure"
	},
	"description":{
		"ru":"Увеличивает шанс нанести цели критический урон.",
		"en":"Increases the chance to deal critical damage."
	},
	"effect":{
		"ru":"Увеличивает шанс крит.попадания на 5%",
		"en":"Increases crit.hit chance for 5%"
	},
	"cost":2,
	"lvlreq":9,
	"rankof":451,
	"column":9
}