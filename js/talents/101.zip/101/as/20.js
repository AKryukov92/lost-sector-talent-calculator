{
	"id":20,
	"imageid":20,
	"name":{
		"ru":"Дробовики (профессионал)",
		"en":"Shotguns (professional)"
	},
	"description":{
		"ru":"Позволяет использовать дробовики армейской классификации.",
		"en":"Shotguns using skill of military classification."
	},
	"cost":1,
	"lvlreq":8,
	"talentreq":14,
	"column":6
}