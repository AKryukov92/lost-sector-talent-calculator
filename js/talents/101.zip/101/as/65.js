{
	"id":65,
	"imageid":65,
	"name":{
		"ru":"Быстрые руки",
		"en":"Quick hands"
	},
	"description":{
		"ru":"Восстанавливает 10 очков действия наемника после использования активного предмета.",
		"en":"Restores 10 AP after using an active item."
	},
	"cost":1,
	"lvlreq":10,
	"talentreq":62,
	"column":3
}