{
	"id":2,
	"imageid":2,
	"name":{
		"ru":"Первая помощь",
		"en":"First Aid"
	},
	"description":{
		"ru":"Позволяет использовать таблетки и инъекции ребиса.",
		"en":"Allows the use of pills and injections of Rebis."
	},
	"cost":1,
	"lvlreq":1,
	"column":1
}