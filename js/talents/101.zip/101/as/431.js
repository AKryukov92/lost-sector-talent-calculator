{
	"id":431,
	"imageid":43,
	"name":{
		"ru":"Быстрый бег",
		"en":"Fast running"
	},
	"description":{
		"ru":"Увеличивает количество очков движения, позволяя передвигаться дальше.",
		"en":"Increases the amount of MP (yellow movement points) allowing to move further."
	},
	"effect":{
		"ru":"Увеличивает максимум очков движения на 5",
		"en":"Increases maximum of move points for 5"
	},
	"cost":1,
	"lvlreq":5,
	"column":7
}