{
	"id":55,
	"imageid":55,
	"name":{
		"ru":"Спринт",
		"en":"Sprint"
	},
	"description":{
		"ru":"Увеличивает мобильность наемника на 40% до конца текущего хода.",
		"en":"Increases mercenary's mobility by 40% until the end of the turn."
	},
	"cost":1,
	"lvlreq":6,
	"talentreq":431,
	"number_of_uses":2,
	"AP_cost":20,
	"column":8
}