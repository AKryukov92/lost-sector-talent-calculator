{
	"id":14,
	"imageid":14,
	"name":{
		"ru":"Дробовики (специалист)",
		"en":"Shotguns (specialist)"
	},
	"description":{
		"ru":"Позволяет использовать дробовики полицейской классификации.",
		"en":"Shotguns using skill of police classification."
	},
	"cost":1,
	"lvlreq":6,
	"column":6
}