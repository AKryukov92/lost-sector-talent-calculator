{
	"id":17,
	"imageid":17,
	"name":{
		"ru":"Химические гранаты",
		"en":"Chemical grenades"
	},
	"description":{
		"ru":"Позволяет использовать химические гранаты.",
		"en":"Allows you to use chemical grenades."
	},
	"cost":1,
	"lvlreq":9,
	"talentreq":25,
	"column":0
}