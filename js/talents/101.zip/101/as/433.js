{
	"id":433,
	"imageid":43,
	"name":{
		"ru":"Быстрый бег",
		"en":"Fast running"
	},
	"description":{
		"ru":"Увеличивает количество очков движения, позволяя передвигаться дальше.",
		"en":"Increases the amount of MP (yellow movement points) allowing to move further."
	},
	"effect":{
		"ru":"Увеличивает максимум очков движения на 11",
		"en":"Increases maximum of move points for 11"
	},
	"cost":3,
	"lvlreq":7,
	"rankof":431,
	"column":7
}