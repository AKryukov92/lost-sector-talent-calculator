{
	"id":54,
	"imageid":54,
	"name":{
		"ru":"Летучка",
		"en":"Inspiration"
	},
	"description":{
		"ru":"Союзники в указанном радиусе от наемника получают увеличение мобильности на 20% на 1 ход. Не действует на активировавшего намника. Не складывается с эффектом спринта.",
		"en":"All your allies in the specified range from the mercenary receive increased mobility by 20% for 1 turn. Does not apply on the activating mercenary. Does not stack with the sprint effect."
	},
	"cost":1,
	"lvlreq":6,
	"talentreq":431,
	"number_of_uses":2,
	"AP_cost":20,
	"radius":20,
	"column":7
}